$(function () {
    $('.bxslider').bxSlider({
        auto: true,
        controls: false,
        pager: true,
        speed: 1000,
        pause: 2000,
    });
})